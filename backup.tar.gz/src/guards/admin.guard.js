"use strict";
exports.__esModule = true;
exports.AdminGuard = void 0;
var AdminGuard = /** @class */ (function () {
    function AdminGuard() {
    }
    AdminGuard.prototype.canActivate = function (context) {
        var req = context.switchToHttp().getRequest();
        if (!req.currentUser) {
            return false;
        }
        return req.currentUser.admin;
    };
    return AdminGuard;
}());
exports.AdminGuard = AdminGuard;
