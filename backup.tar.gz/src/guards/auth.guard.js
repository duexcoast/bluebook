"use strict";
exports.__esModule = true;
exports.AuthGuard = void 0;
var AuthGuard = /** @class */ (function () {
    function AuthGuard() {
    }
    AuthGuard.prototype.canActivate = function (context) {
        var req = context.switchToHttp().getRequest();
        return req.session.userId;
    };
    return AuthGuard;
}());
exports.AuthGuard = AuthGuard;
