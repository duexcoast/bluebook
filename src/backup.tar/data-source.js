"use strict";
exports.__esModule = true;
exports.appDataSource = void 0;
var typeorm_1 = require("typeorm");
exports.appDataSource = new typeorm_1.DataSource({
    type: 'sqlite',
    database: 'db.sqlite',
    entities: ['**/*.entity.ts'],
    migrations: [__dirname + '/migrations/*.ts']
});
