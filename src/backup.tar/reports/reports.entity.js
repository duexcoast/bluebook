"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
exports.__esModule = true;
exports.Report = void 0;
var typeorm_1 = require("typeorm");
var user_entity_1 = require("../users/user.entity");
var Report = /** @class */ (function () {
    function Report() {
    }
    __decorate([
        (0, typeorm_1.PrimaryGeneratedColumn)()
    ], Report.prototype, "id");
    __decorate([
        (0, typeorm_1.Column)({ "default": false })
    ], Report.prototype, "approved");
    __decorate([
        (0, typeorm_1.Column)()
    ], Report.prototype, "price");
    __decorate([
        (0, typeorm_1.Column)()
    ], Report.prototype, "make");
    __decorate([
        (0, typeorm_1.Column)()
    ], Report.prototype, "model");
    __decorate([
        (0, typeorm_1.Column)()
    ], Report.prototype, "year");
    __decorate([
        (0, typeorm_1.Column)()
    ], Report.prototype, "lng");
    __decorate([
        (0, typeorm_1.Column)()
    ], Report.prototype, "lat");
    __decorate([
        (0, typeorm_1.Column)()
    ], Report.prototype, "mileage");
    __decorate([
        (0, typeorm_1.ManyToOne)(function () { return user_entity_1.User; }, function (user) { return user.reports; })
    ], Report.prototype, "user");
    Report = __decorate([
        (0, typeorm_1.Entity)()
    ], Report);
    return Report;
}());
exports.Report = Report;
